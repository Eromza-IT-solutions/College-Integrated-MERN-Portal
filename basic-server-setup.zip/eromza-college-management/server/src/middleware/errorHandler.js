const env = require('../config/env');

// One place that turns every error into the same JSON shape:
// { success: false, message, errors? }
// eslint-disable-next-line no-unused-vars
module.exports = (err, req, res, next) => {
  let status = err.statusCode || 500;
  let message = err.message || 'Something went wrong';
  let errors = err.errors;

  // Mongoose validation failed (required field, bad enum, ...)
  if (err.name === 'ValidationError' && err.errors && !err.isOperational) {
    status = 400;
    message = 'Validation failed';
    errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
  }

  // Bad ObjectId or wrong type in a query
  if (err.name === 'CastError') {
    status = 400;
    message = `Invalid value for ${err.path}`;
  }

  // Duplicate key (unique index), for example the same email twice
  if (err.code === 11000) {
    status = 409;
    const field = Object.keys(err.keyPattern || err.keyValue || {})[0] || 'value';
    message = `${field} already exists`;
  }

  // Unexpected errors: log them, but do not leak details to the client in production.
  if (status >= 500) {
    console.error(err);
    if (env.nodeEnv === 'production') message = 'Internal server error';
  }

  const body = { success: false, message };
  if (errors) body.errors = errors;
  if (env.nodeEnv !== 'production' && status >= 500) body.stack = err.stack;

  res.status(status).json(body);
};
