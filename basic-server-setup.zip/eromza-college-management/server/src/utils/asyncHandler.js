// Wrap async route handlers so a thrown error reaches the error middleware.
// Usage: router.get('/x', asyncHandler(async (req, res) => { ... }));
module.exports = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
