// Mounts every feature's routes under /api/v1.
// Each module keeps its own routes file; add them here as they are built:
//   router.use('/auth', require('../modules/auth/auth.routes'));
const express = require('express');
const mongoose = require('mongoose');

const router = express.Router();

// Quick check that the server and database are up.
router.get('/health', (req, res) => {
  res.json({
    success: true,
    status: 'ok',
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    time: new Date().toISOString(),
  });
});

module.exports = router;
