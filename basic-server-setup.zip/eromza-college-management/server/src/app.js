// Express app: middleware and routes. It does not start listening (see server.js),
// which keeps it easy to test.
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const env = require('./config/env');
const routes = require('./routes');
const notFound = require('./middleware/notFound');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Security headers
app.use(helmet());

// Only our own frontend may call the API. credentials: true is needed for session cookies.
app.use(cors({ origin: env.clientOrigin, credentials: true }));

// Read JSON bodies (small limit; file uploads use their own handler later)
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

if (env.nodeEnv === 'development') app.use(morgan('dev'));

// All API routes live under /api/v1
app.use('/api/v1', routes);

// Must come last
app.use(notFound);
app.use(errorHandler);

module.exports = app;
