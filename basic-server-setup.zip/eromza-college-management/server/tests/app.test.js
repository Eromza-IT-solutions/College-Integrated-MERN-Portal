// Basic checks that need no database. Run with: npm test
process.env.MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/test';
process.env.SESSION_SECRET = process.env.SESSION_SECRET || 'test-secret';
process.env.NODE_ENV = 'test';

const test = require('node:test');
const assert = require('node:assert');
const app = require('../src/app');

let server;
let base;

test.before(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  base = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => server.close());

test('GET /api/v1/health returns ok', async () => {
  const res = await fetch(`${base}/api/v1/health`);
  const body = await res.json();
  assert.strictEqual(res.status, 200);
  assert.strictEqual(body.status, 'ok');
});

test('unknown route returns 404 in the standard error shape', async () => {
  const res = await fetch(`${base}/api/v1/nope`);
  const body = await res.json();
  assert.strictEqual(res.status, 404);
  assert.strictEqual(body.success, false);
});

test('security headers are set', async () => {
  const res = await fetch(`${base}/api/v1/health`);
  assert.ok(res.headers.get('x-content-type-options'));
  assert.strictEqual(res.headers.get('x-powered-by'), null);
});
