// Fixed value lists shared by models, middleware and (through the API) the client.
// Keep these in one place so Backend, Frontend and Database never disagree.
// (This replaces the earlier constants.js. It adds AUTH_TOKEN_PURPOSE, AUTH_TOKEN_TTL_MS,
//  AUDIT_OUTCOME and TEACHER_STATUS. Nothing was removed.)

const ROLES = Object.freeze({
  APPLICANT: 'applicant',
  STUDENT: 'student',
  TEACHER: 'teacher',
  HOD: 'hod',
  WEBSITE_ADMIN: 'websiteAdmin',
  ADMISSION_ADMIN: 'admissionAdmin',
  EXAM_ADMIN: 'examAdmin',
  SUPER_ADMIN: 'superAdmin',
});

// Names shown on screen, used by the seed script.
const ROLE_LABELS = Object.freeze({
  applicant: 'Applicant',
  student: 'Student',
  teacher: 'Teacher',
  hod: 'Head of Department',
  websiteAdmin: 'Website Admin',
  admissionAdmin: 'Admission Admin',
  examAdmin: 'Examination Admin',
  superAdmin: 'Super Admin',
});

const USER_STATUS = Object.freeze({
  PENDING: 'pending', // registered, email not verified yet
  ACTIVE: 'active',
  DEACTIVATED: 'deactivated',
  LOCKED: 'locked',
});

// What a role may do with a resource ...
const PERMISSION_ACTIONS = Object.freeze(['view', 'create', 'update', 'approve', 'delete', 'export']);
// ... and on whose records: only their own, their department's, or everyone's.
const PERMISSION_SCOPES = Object.freeze(['own', 'department', 'all']);

const ACADEMIC_YEAR_STATUS = Object.freeze({
  UPCOMING: 'upcoming',
  CURRENT: 'current',
  CLOSED: 'closed',
});

// Links sent by email.
const AUTH_TOKEN_PURPOSE = Object.freeze({
  EMAIL_VERIFICATION: 'emailVerification',
  PASSWORD_RESET: 'passwordReset',
});

// How long a link works. PROPOSED values: 24 hours to verify, 30 minutes to reset. Team to confirm.
const AUTH_TOKEN_TTL_MS = Object.freeze({
  emailVerification: 24 * 60 * 60 * 1000,
  passwordReset: 30 * 60 * 1000,
});

const AUDIT_OUTCOME = Object.freeze({
  SUCCESS: 'success',
  DENIED: 'denied',
  FAILED: 'failed',
});

const TEACHER_STATUS = Object.freeze({
  ACTIVE: 'active',
  DEACTIVATED: 'deactivated',
});

// Roles that must belong to a department.
const DEPARTMENT_ROLES = [ROLES.TEACHER, ROLES.HOD];

module.exports = {
  ROLES,
  ROLE_LABELS,
  USER_STATUS,
  PERMISSION_ACTIONS,
  PERMISSION_SCOPES,
  ACADEMIC_YEAR_STATUS,
  AUTH_TOKEN_PURPOSE,
  AUTH_TOKEN_TTL_MS,
  AUDIT_OUTCOME,
  TEACHER_STATUS,
  DEPARTMENT_ROLES,
  ROLE_VALUES: Object.values(ROLES),
  USER_STATUS_VALUES: Object.values(USER_STATUS),
  ACADEMIC_YEAR_STATUS_VALUES: Object.values(ACADEMIC_YEAR_STATUS),
  AUTH_TOKEN_PURPOSE_VALUES: Object.values(AUTH_TOKEN_PURPOSE),
  AUDIT_OUTCOME_VALUES: Object.values(AUDIT_OUTCOME),
  TEACHER_STATUS_VALUES: Object.values(TEACHER_STATUS),
};
