Branch: feature/db-seed-permissions   (branch from main, one PR)

Pick the folder that matches server/package.json:
  no "type": "module"  -> commonjs/
  "type": "module"     -> esm/
Copy its server/ files into your repo's server/ (they replace the same-named files):

  server/scripts/seed-permissions.js        NEW
  server/scripts/data/permission-matrix.json NEW  (178 rules, 8 roles; edit this to change a rule)
  server/src/utils/constants.js             CHANGED: Accounts Admin removed (8 roles)
  server/scripts/seed-demo-data.js          CHANGED: no demo Accounts Admin user

Add to server/package.json "scripts":
  "seed:permissions": "node scripts/seed-permissions.js"

Run (dev database):
  npm run seed:permissions
  npm run seed:permissions -- --prune     removes rules not in the matrix

If you already seeded earlier: a demo user accounts.admin@demo.example and an "accountsAdmin"
role row may still exist in your DEV database. The script reports users on that role. Delete
them in Atlas (users collection: email accounts.admin@demo.example; roles collection: key accountsAdmin).

Expected first-run output:
  Permissions: 178 in matrix. Added 178, changed 0, unchanged 0, removed 0.
Second run: Added 0, changed 0, unchanged 178.

Suggested commit message: "feat(db): seed permission matrix, remove Accounts Admin role"
